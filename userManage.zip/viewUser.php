<?php
include "../db/config.php";

// Get user ID from the URL
$userId = $_GET['user_id'] ?? null;

if ($userId) {
    // Fetch user details
    $sql = "SELECT * FROM profiles WHERE user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
    } else {
        echo "User not found.";
        exit;
    }
    $stmt->close();
} else {
    echo "Invalid user ID.";
    exit;
}

$conn->close();
?>