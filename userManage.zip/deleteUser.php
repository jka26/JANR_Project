<?php
// Get user ID from URL
$userId = $_GET['user_id'] ?? null;

if ($userId) {
    // Delete user
    $sql = "DELETE FROM profiles WHERE user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $userId);

    if ($stmt->execute()) {
        header("Location: usermanagement.php?message=User deleted successfully");
        exit;
    } else {
        echo "Error deleting user: " . $stmt->error;
    }
    $stmt->close();
} else {
    echo "Invalid user ID.";
    exit;
}

$conn->close();
?>